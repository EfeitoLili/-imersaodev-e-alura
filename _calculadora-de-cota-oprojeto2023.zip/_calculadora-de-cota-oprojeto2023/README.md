# _Calculadora de Cotação - Projeto2023

A Pen created on CodePen.io. Original URL: [https://codepen.io/efeitolili/pen/bGjmMoe](https://codepen.io/efeitolili/pen/bGjmMoe).

 Add outras moedas para converter;
valor em bitcoin.


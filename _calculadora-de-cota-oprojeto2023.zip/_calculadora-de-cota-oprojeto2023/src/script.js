alert("Olá! Humano  + Bora Cotar?");
var nome = prompt("Qual o seu nome?");

//codigo da primeira aula sem alteração
var valorEmDolar = 64;
var cotacaoDoDolar = 5.32;
var valorEmReal = valorEmDolar * cotacaoDoDolar;
valorEmReal = valorEmReal.toFixed(2);
alert(
  "Sucesso " + nome + " O Valor da Cotação do Dolar fica em R$" + valorEmReal
);

//add outras moedas
var valorEmLibraEsterlina = 1;
var cotacaoDoLibraEsterlina = 6.27;
var valorEmReal = valorEmLibraEsterlina * cotacaoDoLibraEsterlina;
valorEmReal = valorEmReal.toFixed(2);
alert(
  "UAUUU " +
    nome +
    " O Valor da Cotação da Libra Esterlina fica em R$" +
    valorEmReal
);

//Trocar moeda para criptomoeda
var valorEmBitcoin = 2;
var cotacaoDoBitcoin = 116080.16;
var valorEmReal = valorEmBitcoin * cotacaoDoBitcoin;
valorEmReal = valorEmReal.toFixed(2);
alert(
  "Seguraaaa " + nome + " O Valor da Cotação do BTC fica em R$" + valorEmReal
);
